###DesRyan modification request 12th May 2016####
#### ADDITION start Pre-process plink files####
#convert SNPs from letters (ACGT) to numbers (1234). This instruction will also output missing snps

#remove missing genotypes for a SNP locus
./code/plink --noweb --bfile ./uploaded_data/plink --geno 0.999 --make-bed --out ./uploaded_data/plink_geno
#
./code/plink --noweb --bfile ./uploaded_data/plink_geno --recode --make-bed --allele1234 --out ./uploaded_data/plink_1234
#remove missing SNPs

File="./uploaded_data/plink_1234.hh"
if [ -f "$File" ];
then
   #remove missing SNPs
   ./code/plink --noweb --bfile ./uploaded_data/plink_1234 --exclude $File --make-bed --out ./uploaded_data/plink_1234m
else
   #nothing to remove
   mv ./uploaded_data/plink_1234.bed ./uploaded_data/plink_1234m.bed
   mv ./uploaded_data/plink_1234.bim ./uploaded_data/plink_1234m.bim
   mv ./uploaded_data/plink_1234.fam ./uploaded_data/plink_1234m.fam
fi

#prior to merge, reduce the uploaded plink files to the common SNPs (overlap between plink & PAP)
#generate the PAP SNP list
./code/plink --noweb --bfile ./PAP_data/PAP --write-snplist --out ./uploaded_data/snplist
#reduce the new population to these SNPs only
./code/plink --noweb --bfile ./uploaded_data/plink_1234m --extract ./uploaded_data/snplist.snplist --make-bed --out ./uploaded_data/plink_reduced

#need to reduce PAP files now since not all PAP SNPs are in uploaded plink files (now called plink_reduced)
#generate the plink_reduced SNP list
./code/plink --noweb --bfile ./uploaded_data/plink_reduced --write-snplist --out ./uploaded_data/snplistPOP
#reduce PAP files using the snp list from plink_reduced
./code/plink --noweb --bfile ./PAP_data/PAP --extract ./uploaded_data/snplistPOP.snplist --make-bed --out ./uploaded_data/PAP_reduced
###


#try to merge plink_1234m.bed/bim/fam with the reference population
./code/plink --noweb --bfile ./uploaded_data/PAP_reduced --bmerge ./uploaded_data/plink_reduced.bed ./uploaded_data/plink_reduced.bim ./uploaded_data/plink_reduced.fam --make-bed --out ./code_data/merge
#produce a list of flipped snps
File2="./code_data/merge.missnp"
if [ -f "$File2" ];
then
   #flip the problem SNPs
   ./code/plink --noweb --bfile ./uploaded_data/plink_reduced --flip ./code_data/merge.missnp --make-bed --out ./uploaded_data/plink_1234mf
   #30Dec2016
   rm ./code_data/merge.missnp
   ./code/plink --noweb --bfile ./uploaded_data/PAP_reduced --bmerge ./uploaded_data/plink_1234mf.bed ./uploaded_data/plink_1234mf.bim ./uploaded_data/plink_1234mf.fam --make-bed --out ./code_data/merge
fi
#### ADDITION end Pre-process plink files####

##remove any further SNP issues 30Dec2016
File3="./code_data/merge.missnp"
if [ -f "$File3" ];
then
   #remove the problem SNPs
   ./code/plink --noweb --bfile ./uploaded_data/plink_1234mf --exclude ./code_data/merge.missnp --make-bed --out ./uploaded_data/plink_1234mf
   ./code/plink --noweb --bfile ./uploaded_data/PAP_reduced --exclude ./code_data/merge.missnp --make-bed --out ./uploaded_data/PAP_reduced_2
   ./code/plink --noweb --bfile ./uploaded_data/PAP_reduced_2 --bmerge ./uploaded_data/plink_1234mf.bed ./uploaded_data/plink_1234mf.bim ./uploaded_data/plink_1234mf.fam --make-bed --out ./code_data/merge
fi
##remove any further SNP issues 30Dec2016

###DesRyan modification request 12th May 2016####

#### REMOVE start ####
## merge uploaded files with 9 PAPs (reference populations) 
#./code/plink --bfile PAP_data/PAP --bmerge uploaded_data/plink.bed uploaded_data/plink.bim #uploaded_data/plink.fam --make-bed --out code_data/merge --noweb
#### REMOVE end ####


#Create the pop file (merge.pop) for running Admixture in #supervised mode
#The .pop file must contain the names of the reference (PAP) #populations and a line entry (insert '-' character) for each #individual such that the total number of lines equals the total #number of individuals (obtained from the merge.fam in code_data #folder). The file template_merge.pop (in PAP_data folder) #contains the reference population names and 10000 '-' lines. #This file is edited using sed to reduce the 10000 lines to the #required number of individuals 
individs=$(sed -n '$=' ./code_data/merge.fam)
individs=$((individs + 1))
sed -e "$individs, 10000d" ./PAP_data/template_merge.pop >> ./code_data/merge.pop

# run admixture supervised
./code/admixture code_data/merge.bed 9 --supervised -j3

#mv ./admixture_op.out ./results/admixture_op.out

# run the pairing R code
sed -i '1,135d' merge.9.Q #remove the PAP data
R CMD BATCH ./code/matcher.R
sed -i '1i9 Admixture components per individual' merge.9.Q
sed -i '2iNorthEastAsian Mediterranean SouthAfrican SouthWestAsian NativeAmerican Oceanian SouthEastAsian NorthernEuropean SubsaharanAfrican' merge.9.Q
sed -i '1iCase/Control pairs IDs, Match Score (10 max), genetic distance' pairs_case_only.csv
sed -i '1iUnpaired individuals' unpaired_individuals.csv
sed -i '2iID, Case/Control(pre-specified), Age, Gender, 9 admixture components' unpaired_individuals.csv
cat pairs_case_only.csv >> merge.9.Q
cat unpaired_individuals.csv >> merge.9.Q
# end of pairing R code

# move the generated files/results to results folder
rm merge.9.P
mv merge.9.Q ./results/
mv pairs_case_only.csv ./results/
mv unpaired_individuals.csv ./results/
mv matcher.Rout ./results/

#### start remove input & intermediate files####
rm ./uploaded_data/*
rm ./code_data/merge*
#rm pairs*
#rm unpaired*
#rm admixture_op*
#rm matcher*
#### end remove input & intermediate files####


