#setwd("/home/des/webservice_data_test/")
#setwd("/home/des/GPS/Des_Code/Matchmaker_Code_Data/code_and_examples/CaseControlMatch")
setwd("./")
rm(list=ls())
#source('source.R')

#### optimisation method ####
## data file contains 9 admixture components only
## create matrix which contains Individual_ID, gender + 9 chromosomes
## (a) match on Gender & Admixture components (1 + 9 = 10)

#### data input ####
## (a) Merge.9.Q file contains all individuals->optimise pairing (remove 135 PAP(9) individuals
## (b) .Fam file (uploaded data) contains gender data (1 or 2) in column 5 (unset for PAP data)
## all genders to 1 (same sex)

cat("\n","GENDER matching required for case/control pairs? Enter 1 for YES or 0 for NO")
#genderMatchReqd<-scan(n=1)
genderMatchReqd=1
print(genderMatchReqd)
#gender is contained in column 5 of plink.fam file (0=unknown, 1=male, 2=female)
#gender is stored in column 4 of caseData & controlData

cat("\n","Is AGE matching required for case/control pairs? Enter 1 for YES or 0 for NO")
#ageMatchReqd<-scan(n=1)
ageMatchReqd=1
if (ageMatchReqd==1) {
  cat("\n","Maximum AGE DIFFERENCE to be considered a match? Enter value in years")
  #allowed_age_diff<-scan(n=1)
  allowed_age_diff=1000
} else {
  allowed_age_diff=1000#essentially disable age matching by allowing a huge delta
}
#age is contained in column 4 of plink.fam file (0=unknown, 1=male, 2=female)
#age is stored in column 3 of caseData & controlData


cat("\n","Use CASE/CONTROL tags if specified in plank files? Enter 1 for YES or 0 for NO")
#casecontrolMatchReqd<-scan(n=1)
casecontrolMatchReqd=1
print(casecontrolMatchReqd)
#case/control pre-specifier is contained in column 6 of plink.fam file
#case/control pre-specifier is stored in column 2 of caseData & controlData


#separate_case_control_files=1#case file & control file (2 files)
separate_case_control_files=0#0=>one file,1=>two files
#match_threshold=5#up to and including 5
match_threshold=7
delta=0.01
#delta=0.005
#input_file_header=0#

#read one file case.csv
if (separate_case_control_files==0) {

    ##need to read in number of individuals in file/s
    ##note the first 135 entries are the PAP individuals and need to be discarded
    #scopeCase <- read.csv("merge.9.Q",sep=" ",header=input_file_header)
    scopeCase <- read.csv("merge.9.Q",sep=" ",header=FALSE)
    scopeControl <- scopeCase
    dimensions_file_case=dim(scopeCase)
    dimensions_file_control=dim(scopeControl)

    no_cases=dimensions_file_case[1]
    no_controls=dimensions_file_control[1]
    no_fields=dimensions_file_case[2]
    #DR total no_fields = Individuals_ID + gender + no_chroms
    #no_chroms=dimensions_file_case[2]-2#no_chroms=9

    caseData=matrix(0,nrow=no_cases,ncol=no_fields)
    controlData=matrix(0,nrow=no_controls,ncol=no_fields)
    caseData<-scopeCase
    controlData<-scopeControl
    caseData<-round(caseData,digits=3)
    controlData<-round(controlData,digits=3)
    ## need to remove the first 135 rows of caseData & controlData (since PAP data and not involved in pairings)
    #no_cases=no_cases-135
    #no_controls=no_controls-135
    #caseData <- caseData[-1:-135,]
    #controlData<-controlData[-1:-135,]

    ## need to add a column of 1's (as first column) to set Gender data
    ## or read gender from column 5 from .fam file 
    gender <- read.table("./uploaded_data/plink.fam",sep=" ",header=FALSE)
    #gender <- read.table("plink.fam",sep=" ",header=FALSE)    
    genderColumn=matrix(1,nrow=no_cases)
    genderColumn=gender[,5]
    ##include AGE read from column 4 from .fam file
    ageColumn=matrix(1,nrow=no_cases)
    ageColumn=gender[,4]
    ##include CASE/CONTROL read from column 6 from .fam file
    casecontrolColumn=matrix(1,nrow=no_cases)
    casecontrolColumn=gender[,6]
    
    individualID=matrix(1:no_cases,nrow=no_cases)
    
    caseData <- cbind(genderColumn,caseData)
    caseData <- cbind(ageColumn,caseData)
    caseData <- cbind(casecontrolColumn,caseData)   
    caseData <- cbind(individualID,caseData)
      
    controlData <- cbind(genderColumn,controlData)
    controlData <- cbind(ageColumn,controlData)   
    controlData <- cbind(casecontrolColumn,controlData)       
    controlData <- cbind(individualID,controlData)
    
    
    #### allow multi-core execution ####
    #library(parallel)
    #ncor=4
    #SimAllPair=mclapply(ComIdx,function(i){
    #  out=apply(i,1,function(ii) 
    #  rule(RawDa[ii[1],],RawDa[ii[2],]))
    #  out=c(out,rep(0,no_individs-i[1,1]))
    #  out
    #},mc.cores = ncor)"
    ####
    final_best=100
    max_score=100##set to large value since trying to find smallest....make each less than

    ##loop over ordered (ascending) admixture components  
    #for (order_index in 1:9) {
      #### select cases & calculate genetic distance to all controls####
      geneticD_matrix=matrix(0,ncol=no_controls,nrow=no_cases)#utilise Genetic Distance
      geneticScore_matrix=matrix(0,ncol=no_controls,nrow=no_cases)
      copy_geneticScore_matrix=matrix(0,ncol=no_controls,nrow=no_cases)
      copy_geneticD_matrix=matrix(0,ncol=no_controls,nrow=no_cases)

      #case_index=rows of geneticD_matrix
      for (case_index in 1:no_cases) {
	      #print(round(100*case_index/no_cases))
	      #print(paste("GD/score matrix % complete = ", round(100*case_index/no_cases)))
	print(paste("GD/score matrix - ", round(100*case_index/no_cases)," % complete"))
	#control_index=columns of geneticD_matrix
	for (control_index in 1:no_controls) {
	  sum_squares=0#utilise Genetic Distance
	  score=0
	  #for (j in 3:11) {sum_squares = sum_squares + ((controlData[control_index,j]-caseData[case_index,j])^2)}
	  #genetic_distance=sqrt(sum_squares)

	  #gender match i.e. case/control must be male/male or female/female Column 4 of caseData/controlData
	  #age match i.e. case/control must be within xx years Column 3 of caseData/controlData 
	  #TO DO use case/control identifier from plink files Column 2 of caseData/controlData

	  
	 ##13th October 2016 start

	  if (ageMatchReqd==1) {
	    #calculate if age matched for this pair
	    pair_ageMatchReqd=(abs(caseData[case_index,3]-controlData[control_index,3])<=allowed_age_diff)^2#TRUE->1
	  }
	  else {
	    #if not age matched set to true always which allows all age pairings
	    pair_ageMatchReqd=1
	  }
	  
	  if (genderMatchReqd==1) {
	    #calculate if gender matched for this pair
	    pair_genderMatchReqd=(caseData[case_index,4]==controlData[control_index,4])^2#TRUE->1
	  }
	  else {
	    #if not gender matched set to true always which allows all gender pairings
	    pair_genderMatchReqd=1
	  }
	  
	  if (casecontrolMatchReqd==1) {
	    #calculate if casecontrol specified for this pair
	    pair_casecontrolMatchReqd=((caseData[case_index,2]==-9) || (controlData[control_index,2]==-9)) || (abs(caseData[case_index,2]-controlData[control_index,2])==1)^2
	  }
	  else {
	    #if not casecontrol specified set to ??? always which allows all pairings
	    pair_casecontrolMatchReqd=1
	  }
	  
	  #caclulate the score & genetic distance elements
	  if ((pair_ageMatchReqd==1)&&(pair_genderMatchReqd==1)&&(pair_casecontrolMatchReqd==1)) {
	    #pair allowed so calculate score and genetic distance
	    #need to exclude gender from the match score & since otherwise genetic distance is calculated incorrectly 17/10/16
	    #for (j in 4:13) {score = score + ((abs(controlData[control_index,j]-caseData[case_index,j])<=delta)^2)
	    for (j in 5:13) {score = score + ((abs(controlData[control_index,j]-caseData[case_index,j])<=delta)^2)
	    sum_squares = sum_squares + ((controlData[control_index,j]-caseData[case_index,j])^2)#utilise Genetic Distance
	    }	  
	  }
	  else {
	    #pair NOT allowed so set score = 0, & disable genetic distance
	    score=0
	    sum_squares=(999)^2	  
	  }
	 ##13th October 2016 end	  
	 	 
#	  ## start case_control identifiers in plink.fam file checked as non-specified
#	  #if ((caseData[case_index,2]==-9) || (controlData[control_index,2]==-9)) {
#	  if (((caseData[case_index,2]==-9) || (controlData[control_index,2]==-9)) || (abs(caseData[case_index,2]-controlData[control_index,2])==1)) {
#	  ##
#	    if ((caseData[case_index,4]==controlData[control_index,4])&&(abs(caseData[case_index,3]-controlData[control_index,3])<=allowed_age_diff)){
#	      #for (j in 2:11) {score = score + ((controlData[control_index,j]==caseData[case_index,j])^2)}
#	      #tests for matches within +/- delta
#	      for (j in 4:13) {score = score + ((abs(controlData[control_index,j]-caseData[case_index,j])<=delta)^2)
#		sum_squares = sum_squares + ((controlData[control_index,j]-caseData[case_index,j])^2)#utilise Genetic Distance
#	      }
#	    }
#	    else {
#	      score=0
#	      ##if not gender matched make genetic distance large
#	      sum_squares=(999)^2
#	    }
#	  ## does this help? Note if case-control tags preclude any pairing then the prog does not shutdown properly
#	  ##...seems to process for a long long time....infinite loop!?
#	  } else {
#	      score=0
#	      ##if not gender matched make genetic distance large
#	      sum_squares=(999)^2
#	  }
	  ## end case_control identifiers in plink.fam file checked
	  
	  genetic_distance=round(sqrt(sum_squares),digits=3)#utilise Genetic Distance
	  geneticD_matrix[control_index,case_index]=genetic_distance#utilise Genetic Distance
	  geneticD_matrix[case_index,control_index]=genetic_distance#utilise Genetic Distance

	  #MOD if using single file containing all individuals then make diagonal zero
	  if (case_index==control_index) {
	    score=0
	    ##set genetic distance to high positive value for diagonal
	    geneticD_matrix[case_index,case_index]=999
	  }
	  geneticScore_matrix[case_index,control_index]=score

	  }
      }
      #
      ## want to optimise using genetic distance rather than score
      copy_geneticScore_matrix=geneticScore_matrix
      copy_geneticD_matrix = geneticD_matrix

      ### START HERE IF DO NOT WANT TO RECREATE THE SCORE/GENETIC DISTANCE MATRIX
      ###
      
      ### the absolute_max_score of the geneticScore_matrix
      absolute_max_score=0
      #geneticScore_matrix=copy_geneticScore_matrix
      geneticScore_matrix=copy_geneticScore_matrix#switch to genetic distance CAUTION LABELS NOW INCORRECT
      for (case_index in 1:no_cases) {
      max_case=max(geneticScore_matrix[case_index,])
      absolute_max_score=absolute_max_score+max_case
      }
      absolute_max_score=absolute_max_score/2
      print("absolute_max_score")
      print(absolute_max_score)

      #### select nearest, save the pair, remove case and control from matrix ####
      #caution row number verus Ind_ID!!
      #pairs_case_control=matrix(0,nrow=no_cases,ncol=4)

      #pairs_case_control=matrix(0,nrow=floor(no_cases/2),ncol=3)
      #pairs_case_control=matrix(0,nrow=no_cases,ncol=3)#utilise Genetic Distance
      pairs_case_control=matrix(0,nrow=no_cases,ncol=4)#utilise Genetic Distance
      #pairs_case_only=matrix(0,nrow=round(no_cases/2),ncol=3)
      #loop_max=no_cases
      loop_max=100
      #final_best=100
      plot_data=matrix(0,nrow=loop_max,ncol=2)
      #include_extended_maxs=0
      #max_score=100##set to large value since trying to find smallest....make each less than

      ## method to find solution
      single_max=0
      random_max=0
      max_remaining_matrix=0#do not use
      max_remaining_maxs=1
      if ((max_remaining_matrix==1) || (max_remaining_maxs==1) || (single_max==1)) {
      #if ((max_remaining_matrix==1) || (single_max==1)) {
      #if (single_max==1) {
      loop_max=1#no loop required since these methods will produce the same answer every time
      }

      #***********************************number of search iterations start***********************************************
      #*******************************************************************************************************************
      for (loop in 1:loop_max){
	#for (loop in 1:1){
	## use genetic distance
	geneticScore_matrix=copy_geneticD_matrix
	pairs_case_control[,]=0
	score=0
	used_index=matrix(0,no_cases) #keep track of which index has been paired 0 no 1 yes
	#*******************start case loop**************************************
	#*******************start CASE loop 1st part new_startPt -> no_cases************************************** 
	##this loop always starts with case index = 1, now start at random pt called new_startPt
	#new_startPt=round(runif(1,2,no_cases))
	#print("newstartPt = ")
	#print(new_startPt)
	#print(paste("newstartPt = ", new_startPt))
	#print(paste("newstartPt = ", loop))
	#*******************start case loop**************************************
	for (case_index in 1:no_cases) {
	#for (case_index in 1:(new_startPt-1)) {     
	  #print(paste("used_index = ", used_index[case_index]))
	  if (used_index[case_index]==0) {
	    #used_index[case_index]=1 #now used
	    #max_case=max(geneticScore_matrix[case_index,])
	    ##locate the list if minima
	    max_case=min(geneticScore_matrix[case_index,])
	    #max_case=max_case+0.005##increase the number of 'near minima' values considered
	    #how many occurences of max value
	    how_many_maxs=length(which(geneticScore_matrix[case_index,]==max_case,arr.ind=TRUE))
	    ## case when there are no mins in a row and all set to 999
	    if (max_case==999) {
	      how_many_maxs=1
	      }
	      #used_index}
	    ##case when there are no mins in a row and all set to 999
	    ##increase the number of 'near minima' values considered
	    #how_many_maxs=length(which(geneticScore_matrix[case_index,]<=max_case+0.01,arr.ind=TRUE))
	    #print("min_case")
	    #print(max_case)
	    #print("how many minima")
	    #print(how_many_maxs)
	    #declare array variable c to store all these max values for case_index
	    d <- c(how_many_maxs)
	    d=which(geneticScore_matrix[case_index,]==max_case,arr.ind=TRUE)
	    #d=which(geneticScore_matrix[case_index,]<=max_case+0.01,arr.ind=TRUE)

	    # single max start********
	    if (single_max==1) {
	    #select the first row max
	    i=d[1]
	    #used_index[i]=1 #now used #removed on 26/5/16 since causes problem with unpaired pairs
	    }
	    #single max end**********

	    # random max start********
	    if (random_max==1) {
	    #select a row max by random
	    selected=round((runif(1,1,how_many_maxs)))
	    i=d[selected]
	    #used_index[i]=1 #now used
	    }
	    #random max end**********

	    #find out which row index makes the remaining matrix a maximum start*********************
	    if (max_remaining_matrix==1) {
		temp_geneticScore_matrix=geneticScore_matrix
	      #loop over the number of maxima in row, remove that max column from matrix and then calculate total of remaining matrix
	      #loop=loop_max+1#force loop to once since will get same answer for every loop
	      sum_temp_matrix_best=1000000##need to get less than
	      #temp_geneticScore_matrix=geneticScore_matrix
	      for (matrix_max in 1:how_many_maxs){
		temp_geneticScore_matrix=geneticScore_matrix
		temp_geneticScore_matrix[case_index,]=0##999
		temp_geneticScore_matrix[,d[matrix_max]]=0##999
		sum_temp_matrix=sum(temp_geneticScore_matrix)-((no_cases-2)*999)
		#print("sum_temp_matrix")
		#print(sum_temp_matrix)
		if (sum_temp_matrix<sum_temp_matrix_best) {## > -> <
		  best_index=matrix_max
		  sum_temp_matrix_best=sum_temp_matrix
		}
	      #print("best_index")
	      #print(best_index)
	      #print("sum_temp_matrix_best")
	      #print(sum_temp_matrix_best)
	      }
	      #use the row index from the max list that makes the remaining matrix a maximum
	      i=d[best_index]
	    }
	    #print("best index")
	    #print(i)
	    #find out which row index makes the remaining matrix a maximum end*********************

	    #find out which row index makes the sum of the remaining matrix maxima a maximum start*********************
	    if (max_remaining_maxs==1) {
	      #temp_geneticScore_matrix=geneticScore_matrix
	      #sum_casecontrol_maxs_best=0
	      sum_casecontrol_maxs_best=10000##want to find the smallest
	      for (matrix_max in 1:how_many_maxs){
		temp_geneticScore_matrix=geneticScore_matrix
		#temp_geneticScore_matrix[,d[matrix_max]]=0
		##remove the case_index row & selected minima column from temp_geneticScore_matrix
		temp_geneticScore_matrix[,d[matrix_max]]=999##want to find the smallest
		temp_geneticScore_matrix[case_index,]=999##want to find the smallest
		sum_casecontrol_maxs=0
		#for (search_index in 1:no_cases) {
		for (search_index in case_index:no_cases) {##don't consider anything row 'above' case_index      
		  if (search_index==case_index) {
		    new_max_case=0
		  } else {
		      #new_max_case=max(temp_geneticScore_matrix[search_index,])
		      new_max_case=min(temp_geneticScore_matrix[search_index,])##want to find the smallest
		      if (new_max_case==999) {##last entry probably all set to 999
			new_max_case=0
			}
		  }
		  sum_casecontrol_maxs=sum_casecontrol_maxs + new_max_case
		}
		#if (sum_casecontrol_maxs>sum_casecontrol_maxs_best) {
		##want to find the smallest
		if (sum_casecontrol_maxs<=sum_casecontrol_maxs_best) {
		  best_index=matrix_max
		  sum_casecontrol_maxs_best=sum_casecontrol_maxs
		}
	      }
	      #use the row index from the max list that makes the remaining matrix a maximum
	      i=d[best_index]
	    }
	    #find out which row index makes the sum of the remaining matrix maxima a maximum end*********************


	    j=geneticScore_matrix[case_index,i]
	    ## remove threshold which is used to determine if acceptable pairing or not	  
	    #if (j>match_threshold) { #>= match_threshold => match DR 24/8/2016
	    #print(paste("used_index = ", used_index[i]))
	      if  (used_index[i]==0) {##check that the found match has not been previously used DR 24/8/2016
		if (copy_geneticScore_matrix[case_index,i]>=match_threshold) {# DR 24/8/2016
		  used_index[case_index]=1 #now used
		  used_index[i]=1 #now used
		  score=score+j
		  #this is just a matrix index
		  #pairs_case_control[case_index,1]=case_index
		  #make this case Ind_ID
		  pairs_case_control[case_index,1]=caseData[case_index,1]
		  #pairs_case_only[case_index,1]=caseData[case_index,1]
		  #this is just a matrix index
		  #pairs_case_control[case_index,2]=i
		  #make this control Ind_ID
		  pairs_case_control[case_index,2]=controlData[i,1]
		  #pairs_case_only[case_index,2]=controlData[i,1]	  
		  #record the score for this pair
		  ##ensure still access score
		  #pairs_case_control[case_index,3]=geneticScore_matrix[case_index,i]
		  pairs_case_control[case_index,3]=copy_geneticScore_matrix[case_index,i]
		  #record the genetic distance for this pair
		  #pairs_case_control[case_index,4]=geneticD_matrix[case_index,i]	    	    
		  pairs_case_control[case_index,4]=copy_geneticD_matrix[case_index,i]	  
		  #disable this control column from max score finder
		  #geneticScore_matrix[,i]=-999
		  ##need to make the used IDs high
		  #geneticScore_matrix[,i]=0
		  #geneticScore_matrix[i,]=0
		  geneticScore_matrix[,i]=999
		  geneticScore_matrix[i,]=999
		  #MOD if using single file containing all individuals then make i column & i row zero
		  #geneticScore_matrix[case_index,]=0
		  #geneticScore_matrix[,case_index]=0
		  geneticScore_matrix[case_index,]=999
		  geneticScore_matrix[,case_index]=999
		} # DR 24/8/2016
	      }##check that the found match has not been previously used DR 24/8/2016
	    #} #DR 24/8/2016
	  }#end of used_index==0
	  
	}#*******************end CASE loop 1st part**************************************
	  
	#}
	#### output pairs ####
	#if (score>max_score) {
	if (score<=max_score) { #need to find minimum => change to < 'less than'
	  #### data output ####
	  max_score = score
	  ##Go through each row and determine if a value is zero
	  row_sub=apply(pairs_case_control,1,function(row) !(all(row==0)))
	  ##Subset as usual
	  final_pairs=pairs_case_control[row_sub,]
	  final_used_index = used_index #record which individuals are paired/not paired
	  
	  #for single file need to output first HALF of the pairs_case_control[] matrix
	  if (separate_case_control_files==1){
		  #write the fist half of pairs_case_control[] matrix
	      write.table(final_pairs,file="pairs_case_control.csv",eol = "\n",row.names = FALSE,col.names = FALSE)
	  }
	  else{
		  #write the fist half of pairs_case_control[] matrix
		  #pairs_case_only<-pairs_case_control[1:round(no_cases/2),]
		  #write.table(pairs_case_only,file="pairs_case_only.csv")
		 #write.table(final_pairs,file="pairs_case_only.csv",eol = "\n",row.names = FALSE,col.names = FALSE)
		  write.table(final_pairs,file="pairs_case_only.csv",eol = "\n",row.names = FALSE,col.names = FALSE)
	  }
	  print(score)
	}
	plot_data[loop,1]=loop
	plot_data[loop,2]=score

	if (score<final_best) {
	  final_best=score
	  print(paste("best score = ", final_best))
	  }
	print(paste("Total score = ", score))
	print(paste("Loop index = ", loop))
	print("next part of loop")
      }
      #***********************************number of search iterations end***********************************************
      #*****************************************************************************************************************
      #plot_data <- data.frame(plot_data)
      #require(ggplot2)
  
      #hist(plot_data[,2])
      print("max_score found")
      print(max_score)
      print("absolute_max_score")
      print(absolute_max_score)
      
      ## Output information on the unpaired individuals
      fileConn<-file("unpaired_individuals.csv")
      #fileConn<-file("unpaired_individuals.txt")
      text1="Unpaired individuals ID, Gender, & 9 admixture components"
      unpaired_data=caseData
      unpaired_data[,]=0  
      for (loop_test in 1:no_cases) {
	#write(cat(loop_test,"\n"), fileConn,append=TRUE)
	#write(loop_test, fileConn,append=TRUE)
	if (final_used_index[loop_test]==0) {
	  unpaired_data[loop_test,]=caseData[loop_test,]	
	}
      }
      ##Go through each row and determine if a value is zero
      row_sub=apply(unpaired_data,1,function(row) all(row == 0))
      ##Subset as usual
      unpaired_datas=unpaired_data[!row_sub,] 
      write("Unpaired individuals", fileConn)
      write.table(unpaired_datas,fileConn,eol = "\n",row.names = FALSE,col.names = FALSE,append=TRUE)
      fileConn->close.connection
      
      print("final_best")
      print(final_best)
     
     ###
     ### END HERE IF DO NOT WANT TO RECREATE THE SCORE/GENETIC DISTANCE MATRIX 
} else {
  print("separate case control files")
}
